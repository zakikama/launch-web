
import Test2 from "../../pages/test2";

export default function Home() {
  return (
   <>
       <Test2 />
   </>



  )
}
